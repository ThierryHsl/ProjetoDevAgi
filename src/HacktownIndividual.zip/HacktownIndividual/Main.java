package HacktownIndividual;

public class Main {
    public static void main(String[] args) {

        Analista ana = new Analista("Thierry", 2000);
        Gerente ger = new Gerente(" Matheus", 3000);

        ger.exibir();
        ger.bonus();

        ana.exibir();
        ana.bonus();


    }
}
