package HacktownIndividual;

public interface BonusFixo {

    public void bonus();
}